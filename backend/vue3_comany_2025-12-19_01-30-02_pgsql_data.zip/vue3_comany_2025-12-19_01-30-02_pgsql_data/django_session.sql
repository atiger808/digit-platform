--
-- PostgreSQL database dump
--

\restrict M7ZEp27N4mGMVceNP6CJ3F8aMDV2K2AwYdtlQPpNdgZvNt8UUTGwRfbzB2O1aJQ

-- Dumped from database version 18.0
-- Dumped by pg_dump version 18.0

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET transaction_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

DROP INDEX public.django_session_session_key_c0390e0f_like;
DROP INDEX public.django_session_expire_date_a5c62663;
ALTER TABLE ONLY public.django_session DROP CONSTRAINT django_session_pkey;
DROP TABLE public.django_session;
SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: django_session; Type: TABLE; Schema: public; Owner: vue3_comany
--

CREATE TABLE public.django_session (
    session_key character varying(40) NOT NULL,
    session_data text NOT NULL,
    expire_date timestamp with time zone NOT NULL
);


ALTER TABLE public.django_session OWNER TO vue3_comany;

--
-- Data for Name: django_session; Type: TABLE DATA; Schema: public; Owner: vue3_comany
--

COPY public.django_session (session_key, session_data, expire_date) FROM stdin;
201agcvb3005iaz55idpz2209bi6wirs	e30:1uCAhD:kac0tsi0F_oQCH9V3gQKh8-7lJA7xFiz5vxG742HG8Y	2025-05-20 13:18:23.552+08
4leg142qi03hvrbih3d7xexcn3j1v2tt	e30:1uCAqO:sK3QNbvb4C3wyF8ASExK2SN-s8OLRXkJYqBftbgyzRI	2025-05-20 13:27:52.802+08
ct7ple6nci1rcy5kfwpuqzsk6zgxoihn	e30:1uCAvN:rJzVsjAsHqK-9nhsqFa74rto98GJpj8VM86NfaMpeAk	2025-05-20 13:33:01.141+08
flo8qyypukc8wlaj3c191nhi40o7v1bw	.eJxVjMsOwiAURP-FtSEgb5fu_QZy4V6kaiAp7cr477ZJF7qaZM6ZebMI61LjOmiOE7ILk-z02yXIT2o7wAe0e-e5t2WeEt8VftDBbx3pdT3cv4MKo25rCs6IYjR4H4hC8NJKs6UpzmqCopLyAkRRmMEjunImzCqoZJRBtJp9vt-VOC0:1u5M4p:sYd8jlhGsGnnWWVbtquU5GsCMrMINhMsiBcQSg2aMhc	2025-05-01 18:02:35.528+08
kw98bfjmoj5o5snwjzyz0s9qykzjtzp4	e30:1uCAhO:0ff4CO6xXcHOYoXcz1lNyuxdP0TFgbckoHpGEt2BSq4	2025-05-20 13:18:34.23+08
ujaa1qmwbv141nkvowkbg2doy9raua57	.eJxVjEEOgjAQRe_StWmYFmrHpXvO0AwzU4saSCisjHdXEha6_e-9_zKJtrWkreqSRjEXA-b0uw3ED512IHeabrPleVqXcbC7Yg9abT-LPq-H-3dQqJZvjb5Ddh1pDI3PmlXINRz5nDkggrAiMEkLDQOIuowuQIhIwXvfDtG8P_f9OAw:1uCYHI:Pn6rDjE0DT87yfknAKDhnNjSXL-1E1A1V2AYmolvlIM	2025-05-21 14:29:12.476+08
x1f3972g4f3yj2xau2et287xaf0auz8j	.eJxVjEEOwiAURO_C2hCgQMGl-56B_PI_UjWQlHZlvLsl6UJXk5n3Mm8WYN9y2ButYUF2ZZJdfrcZ4pNKB_iAcq881rKty8y7wk_a-FSRXrfT_TvI0HK_1V4qct6nJJOOzlrUBkF4cB4MEFkUNGDUajxCJUdAzthBRiOOMrLPF-m1OE8:1uMg5R:AOoaKDly0YQ5vzO2db4Moz7M0wijrzUC2UysTwovOHQ	2025-06-18 12:50:49.067+08
6kragxxwl2m7f22w72625sqrbe9r20pr	.eJxVjEEOwiAURO_C2hCgQMGl-56B_PI_UjWQlHZlvLsl6UJXk5n3Mm8WYN9y2ButYUF2ZZJdfrcZ4pNKB_iAcq881rKty8y7wk_a-FSRXrfT_TvI0HK_1V4qct6nJJOOzlrUBkF4cB4MEFkUNGDUajxCJUdAzthBRiOOMrLPF-m1OE8:1uN4wU:KB92guHpOOnooCRqQ_YO6tU2YT59_tHFDGxnkyCdEiQ	2025-06-19 15:23:14.489994+08
4tdjsscqqf0gma2f0gpnksukntptehg7	.eJxVjEEOgjAQRe_StWmmtE4Zl-45A5kpU4saSCisjHdXEha6_e-9_zI9b2vpt6pLPw7mYpw5_W7C6aHTDoY7T7fZpnlal1HsrtiDVtvNgz6vh_t3ULiWb-2jIgslAUiMhE4EmkC-DRqUGvCafQblTOIRVQHPIBAotg4yRTTvD-OVN3U:1uUddU:D8USdijrSrzoL1xsoglwe2bLSE4ZB6EmlZJg-2AcB-Q	2025-07-10 11:50:52.146011+08
7mk1jfw49i2mhnmlk4p1igl02xmf2kd0	.eJxVjEEOgjAQRe_StWmmtE4Zl-45A5kpU4saSCisjHdXEha6_e-9_zI9b2vpt6pLPw7mYpw5_W7C6aHTDoY7T7fZpnlal1HsrtiDVtvNgz6vh_t3ULiWb-2jIgslAUiMhE4EmkC-DRqUGvCafQblTOIRVQHPIBAotg4yRTTvD-OVN3U:1uWron:uBkp-PjpRPyr-qV4pwrt5T_8DED0aNInKUA1FoSowQY	2025-07-16 15:23:45.4076+08
bjptprs6ghpkedzlknsppoz7xsuzdpdm	.eJxVjEEOgjAQRe_StWmmtE4Zl-45A5kpU4saSCisjHdXEha6_e-9_zI9b2vpt6pLPw7mYpw5_W7C6aHTDoY7T7fZpnlal1HsrtiDVtvNgz6vh_t3ULiWb-2jIgslAUiMhE4EmkC-DRqUGvCafQblTOIRVQHPIBAotg4yRTTvD-OVN3U:1ucLO3:yGi6XgHQfhtzb_M-oHrME9e6FHk4WVPJu67nge0Lt0U	2025-07-31 17:58:47.562046+08
ib0b79nxli2ms6n83k05jrqss6sw1kq6	.eJxVjEEOgjAQRe_StWmmtE4Zl-45A5kpU4saSCisjHdXEha6_e-9_zI9b2vpt6pLPw7mYpw5_W7C6aHTDoY7T7fZpnlal1HsrtiDVtvNgz6vh_t3ULiWb-2jIgslAUiMhE4EmkC-DRqUGvCafQblTOIRVQHPIBAotg4yRTTvD-OVN3U:1uheKj:ZWWPZKo-ST6d4x8jTDkaOltPTKDEWusTFWYUlYyHi0E	2025-08-15 09:13:17.447905+08
2tumpv4x45swip4lf783sxxytdsv2umf	.eJxVjEEOgjAQRe_StWmmtE4Zl-45A5kpU4saSCisjHdXEha6_e-9_zI9b2vpt6pLPw7mYpw5_W7C6aHTDoY7T7fZpnlal1HsrtiDVtvNgz6vh_t3ULiWb-2jIgslAUiMhE4EmkC-DRqUGvCafQblTOIRVQHPIBAotg4yRTTvD-OVN3U:1umnR2:TvI7A1_0JF4quBtLGB1nBUUd-MCj0Ec2uXc1sTXoCtg	2025-08-29 13:57:04.894166+08
442fhy66tcxvnoc27xa4a7jv4dige8es	.eJxVjEEOgjAQRe_StWmmtE4Zl-45A5kpU4saSCisjHdXEha6_e-9_zI9b2vpt6pLPw7mYpw5_W7C6aHTDoY7T7fZpnlal1HsrtiDVtvNgz6vh_t3ULiWb-2jIgslAUiMhE4EmkC-DRqUGvCafQblTOIRVQHPIBAotg4yRTTvD-OVN3U:1urtUh:FO_XzY2WYXBHO_4VeLBi1QP8ZoFIoWYqMf55eaKNccU	2025-09-12 15:25:55.355984+08
lpf07koin5fseimk8r83un787x16p9r3	.eJxVjEEOgjAQRe_StWmmtE4Zl-45A5kpU4saSCisjHdXEha6_e-9_zI9b2vpt6pLPw7mYpw5_W7C6aHTDoY7T7fZpnlal1HsrtiDVtvNgz6vh_t3ULiWb-2jIgslAUiMhE4EmkC-DRqUGvCafQblTOIRVQHPIBAotg4yRTTvD-OVN3U:1ux0az:3EA3MZOmNiPc58hS1qXAbgtbF-fcJ-HTReR4JRc4bwg	2025-09-26 18:01:33.426384+08
i6f7k7adryze5mu6t6t6kgyulzdeygmb	.eJxVjEEOgjAQRe_StWmmtE4Zl-45A5kpU4saSCisjHdXEha6_e-9_zI9b2vpt6pLPw7mYpw5_W7C6aHTDoY7T7fZpnlal1HsrtiDVtvNgz6vh_t3ULiWb-2jIgslAUiMhE4EmkC-DRqUGvCafQblTOIRVQHPIBAotg4yRTTvD-OVN3U:1v6hOu:Rglqbk_LoBb-pMrJBE-oqMDBIEx1UpUq0qSiksG6tyk	2025-10-23 11:33:08.304367+08
vi2rtaqsk4c62cg05vkaxeisq9cvjaym	.eJxVjEEOgjAQRe_StWmmtE4Zl-45A5kpU4saSCisjHdXEha6_e-9_zI9b2vpt6pLPw7mYpw5_W7C6aHTDoY7T7fZpnlal1HsrtiDVtvNgz6vh_t3ULiWb-2jIgslAUiMhE4EmkC-DRqUGvCafQblTOIRVQHPIBAotg4yRTTvD-OVN3U:1vFAay:wbfUYsfAJmlLmqTty7mVqMEzirJ64n1Zsu7RWL4SaeY	2025-11-15 20:20:36.815591+08
9kdfpf876zsxwpkoz8vxku1xq260m5ak	.eJxVjMsOwiAQRf-FtSHAlMe4dO83kJlCpWogKe3K-O_apAvd3nPOfYlI21ri1vMS5yTOQovT78Y0PnLdQbpTvTU5trouM8tdkQft8tpSfl4O9--gUC_fOgxOe68DGLQclAEFGlJQ5DkZNyHZYCdGxAETMwUgb11G9OiArQXx_gCh2zZ6:1vMjDo:RDPLpP4SdUKN20YYu1HX3iwA26DsNkg1vhYYfdyAKT8	2025-12-06 16:43:56.632507+08
pc46z5m3slvpxir969h2wm0d3dxl6ssu	.eJxVjMsOwiAQRf-FtSHAlMe4dO83kJlCpWogKe3K-O_apAvd3nPOfYlI21ri1vMS5yTOQovT78Y0PnLdQbpTvTU5trouM8tdkQft8tpSfl4O9--gUC_fOgxOe68DGLQclAEFGlJQ5DkZNyHZYCdGxAETMwUgb11G9OiArQXx_gCh2zZ6:1vQKrg:_yJbqgG5QQWhfNn5alzY2OarfD7MOqozena0KXSVMxY	2025-12-16 15:32:00.337348+08
qhrmm7giiseba835w5u2tv0f4leno1q1	.eJxVjMsOwiAQRf-FtSHAlMe4dO83kJlCpWogKe3K-O_apAvd3nPOfYlI21ri1vMS5yTOQovT78Y0PnLdQbpTvTU5trouM8tdkQft8tpSfl4O9--gUC_fOgxOe68DGLQclAEFGlJQ5DkZNyHZYCdGxAETMwUgb11G9OiArQXx_gCh2zZ6:1vQdpI:cLM2-nV6KBPGryPhOgxNfTU_bP1OLIlsXV8sxf6S_5A	2025-12-17 11:46:48.168551+08
\.


--
-- Name: django_session django_session_pkey; Type: CONSTRAINT; Schema: public; Owner: vue3_comany
--

ALTER TABLE ONLY public.django_session
    ADD CONSTRAINT django_session_pkey PRIMARY KEY (session_key);


--
-- Name: django_session_expire_date_a5c62663; Type: INDEX; Schema: public; Owner: vue3_comany
--

CREATE INDEX django_session_expire_date_a5c62663 ON public.django_session USING btree (expire_date);


--
-- Name: django_session_session_key_c0390e0f_like; Type: INDEX; Schema: public; Owner: vue3_comany
--

CREATE INDEX django_session_session_key_c0390e0f_like ON public.django_session USING btree (session_key varchar_pattern_ops);


--
-- PostgreSQL database dump complete
--

\unrestrict M7ZEp27N4mGMVceNP6CJ3F8aMDV2K2AwYdtlQPpNdgZvNt8UUTGwRfbzB2O1aJQ

