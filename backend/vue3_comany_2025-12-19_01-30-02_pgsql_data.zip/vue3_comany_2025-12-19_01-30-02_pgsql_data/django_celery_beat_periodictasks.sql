--
-- PostgreSQL database dump
--

\restrict tqsdoi1Uv2Xt3Igws8DCyabKcBYMSMemHjyWhuZrNBEI5Xn8440SKssAXUlgkb5

-- Dumped from database version 18.0
-- Dumped by pg_dump version 18.0

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET transaction_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

ALTER TABLE ONLY public.django_celery_beat_periodictasks DROP CONSTRAINT django_celery_beat_periodictasks_pkey;
DROP TABLE public.django_celery_beat_periodictasks;
SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: django_celery_beat_periodictasks; Type: TABLE; Schema: public; Owner: vue3_comany
--

CREATE TABLE public.django_celery_beat_periodictasks (
    ident smallint NOT NULL,
    last_update timestamp with time zone NOT NULL
);


ALTER TABLE public.django_celery_beat_periodictasks OWNER TO vue3_comany;

--
-- Data for Name: django_celery_beat_periodictasks; Type: TABLE DATA; Schema: public; Owner: vue3_comany
--

COPY public.django_celery_beat_periodictasks (ident, last_update) FROM stdin;
1	2025-06-13 11:56:48.50229+08
\.


--
-- Name: django_celery_beat_periodictasks django_celery_beat_periodictasks_pkey; Type: CONSTRAINT; Schema: public; Owner: vue3_comany
--

ALTER TABLE ONLY public.django_celery_beat_periodictasks
    ADD CONSTRAINT django_celery_beat_periodictasks_pkey PRIMARY KEY (ident);


--
-- PostgreSQL database dump complete
--

\unrestrict tqsdoi1Uv2Xt3Igws8DCyabKcBYMSMemHjyWhuZrNBEI5Xn8440SKssAXUlgkb5

